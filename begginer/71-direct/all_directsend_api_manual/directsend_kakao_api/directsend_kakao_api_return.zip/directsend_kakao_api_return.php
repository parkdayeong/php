<?php
// KAKAO API Return_url 샘플 예제입니다.
// return값을 전달받아 기록할 log 위치를 지정합니다.
// 발송결과값은 JSON형식 POST값으로 전달됩니다.
// 카카오 ResultCode - 0 : 성공 / 1 : 미사용 또는 미지원단말기 / 2 : 메시지가 템플릿과 불일치 / 3 : 메시지 타임아웃 / 4 : 발신 프로필 키가 유효하지 않음 / 5 : 카카오 시스템 오류 / 6 : 잘못된 번호 / 7 : 기준 글자수 초과 / 99 : 기타
// 대체문자 ResultCode - 0 : 성공 / 2,5,7 : 네트워크에러 / 4 :잘못된번호 / 6 : 음영지역 / 9 : 번호도용 문자차단 / 20 : 수신거부 / 21 : 90byte초과 / 1,3,8,10,11,12,13,14,15,99 : 기타
// Type - KAKAO : 카카오 발송 / SMS : 대체문자 SMS / LMS : 대체문자 LMS / MMS : 대체문자 MMS

$fp = @fopen('/User Directory/log/'.'log_kakao'.date('Ymd'), 'a');
if ($fp) {
    @fwrite($fp, print_r("[Time : " . date("Y-m-d H:i:s",time()), true ) ."] ");
    @fclose($fp);
}

if (isset($_SERVER["CONTENT_TYPE"]) && strpos($_SERVER["CONTENT_TYPE"], "application/json") !== false) {
    $_POST = array_merge($_POST, (array) json_decode(trim(file_get_contents('php://input')), true));
}

error_log(json_encode($_POST));

$fp = @fopen('/User Directory/log/'.'log_kakao'.date('Ymd'), 'a');
if ($fp) {
    @fwrite($fp, print_r("[Sending result : ",true));
    @fwrite($fp, print_r( json_encode($_POST), true ) ."]\r\n");
    @fclose($fp);
}

?>