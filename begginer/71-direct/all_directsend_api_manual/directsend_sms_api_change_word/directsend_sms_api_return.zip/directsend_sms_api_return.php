<?php
// SMS API Return_url 샘플 예제입니다.
// return값을 전달받아 기록할 log 위치를 지정합니다.
// 발송결과값은 JSON형식 POST값으로 전달됩니다.
// ResultCode - 0 : 성공 / 2,5,7 : 네트워크에러 / 4 :잘못된번호 / 6 : 음영지역 / 9 : 번호도용 문자차단 / 20 : 수신거부 / 21 : 90byte초과 / 1,3,8,10,11,12,13,14,15,99 : 기타

$fp = @fopen('/User Directory/log/'.'log_sms'.date('Ymd'), 'a');
if ($fp) {
	@fwrite($fp, print_r("[Time : " . date("Y-m-d H:i:s",time()), true ) ."] ");
	@fclose($fp);
}

if (isset($_SERVER["CONTENT_TYPE"]) && strpos($_SERVER["CONTENT_TYPE"], "application/json") !== false) {
        $_POST = array_merge($_POST, (array) json_decode(trim(file_get_contents('php://input')), true));
}

error_log(json_encode($_POST));

$fp = @fopen('/User Directory/log/'.'log_sms'.date('Ymd'), 'a');
if ($fp) {
	@fwrite($fp, print_r("[Sending result : ",true));
    @fwrite($fp, print_r( json_encode($_POST), true ) ."]\r\n");
    @fclose($fp);
}

?>