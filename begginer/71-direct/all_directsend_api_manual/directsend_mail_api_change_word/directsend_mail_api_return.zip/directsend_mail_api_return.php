<?php
// MAIL API Return_url 샘플 예제입니다.
// return값을 전달받아 기록할 log 위치를 지정합니다.
// 발송결과값은 JSON형식 POST값으로 전달됩니다.
// State - 1 : 발송대기 / 2 : 성공 / 3 : 일시적 / 4 : 도메인에러 / 5 : 서버연결 / 6 : 메일박스 / 7 : 기타 / 8 : 수신거부
// IsNeedResend - 2차발송 여부

$filename = '/User Directory/log/'.'log_mail'.date('Ymd');

$fp = @fopen($filename, 'a');
if ($fp) {
    @fwrite($fp, print_r("[Time : " . date("Y-m-d H:i:s",time()), true ) ."] ");
    @fclose($fp);
}

if (isset($_SERVER["CONTENT_TYPE"]) && strpos($_SERVER["CONTENT_TYPE"], "application/json") !== false) {
    $_POST = array_merge($_POST, (array) json_decode(trim(file_get_contents('php://input')), true));
}

error_log(json_encode($_POST));

$fp = @fopen($filename, 'a');
if ($fp && $_POST) {
    @fwrite($fp, print_r("[Sending result : ",true));
    @fwrite($fp, print_r( json_encode($_POST), true ) ."]\r\n");
    @fclose($fp);
}
?>