<?php
// MAIL API Option Return_url 샘플 예제입니다.
// return값을 전달받아 기록할 log 위치를 지정합니다.
// 발송 옵션 결과값은 GET값으로 전달됩니다.
// http://test.domain.com?type=[click | open | reject]&mail_id=[MailID]&email=[Email]&sendtime=[SendTime]&mail_reserve_id=[MailReserveID]

$filename = '/User Directory/log/'.'log_mail_option'.date('Ymd');

//발송 옵션(오픈/클릭/수신거부) 결과값 리턴
$fp = @fopen($filename, 'a');
if ($fp && $_GET) {
    @fwrite($fp, print_r("[Option return : ",true));
    @fwrite($fp, print_r( json_encode($_GET), true ) ."]\r\n");
    @fclose($fp);
}
?>